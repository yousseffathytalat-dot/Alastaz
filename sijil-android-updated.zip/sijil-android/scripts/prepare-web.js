// يجهّز مجلد assets/www: ينسخ الصفحة وينزّل الخطوط محلياً (@fontsource) عشان التطبيق يشتغل أوفلاين
const fs = require('fs'), path = require('path');
const root = path.resolve(__dirname, '..');
const out = path.join(root, 'app/src/main/assets/www');
const fonts = ['cairo','el-messiri','tajawal','almarai','noto-kufi-arabic','reem-kufi','changa','amiri','lemonada','ibm-plex-sans-arabic'];
const weights = ['400','600','700'];
fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(path.join(out, 'fonts'), { recursive: true });
let links = '';
for (const f of fonts) {
  const pkg = path.join(root, 'node_modules/@fontsource', f);
  if (!fs.existsSync(pkg)) { console.warn('missing font package', f); continue; }
  const dst = path.join(out, 'fonts', f);
  fs.mkdirSync(path.join(dst, 'files'), { recursive: true });
  for (const w of weights) {
    const css = path.join(pkg, w + '.css');
    if (!fs.existsSync(css)) continue;
    fs.copyFileSync(css, path.join(dst, w + '.css'));
    links += `<link rel="stylesheet" href="fonts/${f}/${w}.css">\n`;
  }
  for (const file of fs.readdirSync(path.join(pkg, 'files'))) {
    if (/-(400|600|700)-normal\.woff2$/.test(file) && /-(arabic|latin)-/.test(file))
      fs.copyFileSync(path.join(pkg, 'files', file), path.join(dst, 'files', file));
  }
}
const SHIM = `<script>(function(){var B=window.AndroidBridge;if(!B||!B.notify)return;
function N(t,o){B.notify(String(t),String((o&&o.body)||""))}
N.permission=B.hasNotifPerm()?"granted":"default";
N.requestPermission=function(){return new Promise(function(res){window.__np=function(g){N.permission=g?"granted":"denied";res(N.permission)};B.requestNotifPerm()})};
window.Notification=N})();</script>`;
let html = fs.readFileSync(path.join(root, 'web/index.html'), 'utf8');
const re = /<link rel="stylesheet" href="https:\/\/fonts\.googleapis\.com[^>]*>/;
if (!re.test(html)) throw new Error('google fonts link not found');
html = html.replace(re, links);
html = html.replace('<head>', '<head>' + SHIM);
fs.writeFileSync(path.join(out, 'index.html'), html);
console.log('www ready');
