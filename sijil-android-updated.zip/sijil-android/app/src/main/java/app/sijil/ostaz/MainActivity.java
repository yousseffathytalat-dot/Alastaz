package app.sijil.ostaz;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String CH = "alerts";
    private WebView wv;
    private int sat = 0, sab = 0, nid = 1;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        // الرسم تحت شريط الحالة مسموح، والصفحة نفسها هي اللي بتقرر تنزل تحته ولا لأ
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        wv = new WebView(this);
        wv.setBackgroundColor(Color.parseColor("#060C0A"));
        wv.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#060C0A"));
        root.addView(wv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        WebSettings st = wv.getSettings();
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        st.setAllowFileAccess(false);
        st.setAllowContentAccess(false);
        st.setTextZoom(100);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try { // tel: / sms: / واتساب / أي رابط خارجي يتفتح برا التطبيق
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) { }
                return true;
            }
            @Override
            public void onPageFinished(WebView v, String url) { pushInsets(); }
        });
        wv.addJavascriptInterface(new Bridge(), "AndroidBridge");

        ViewCompat.setOnApplyWindowInsetsListener(root, (v, ins) -> {
            Insets sys = ins.getInsets(WindowInsetsCompat.Type.systemBars()
                    | WindowInsetsCompat.Type.displayCutout());
            int ime = ins.getInsets(WindowInsetsCompat.Type.ime()).bottom;
            boolean kb = ime > sys.bottom;
            sat = sys.top;
            sab = kb ? 0 : sys.bottom;
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) wv.getLayoutParams();
            int mb = kb ? ime : 0;
            if (lp.bottomMargin != mb) { lp.bottomMargin = mb; wv.setLayoutParams(lp); }
            pushInsets();
            return WindowInsetsCompat.CONSUMED;
        });

        wv.loadUrl("https://" + HOST + "/assets/www/index.html");
    }

    private void pushInsets() {
        if (wv == null) return;
        float d = getResources().getDisplayMetrics().density;
        wv.evaluateJavascript("document.documentElement.style.setProperty('--sat','" + (sat / d) + "px');"
                + "document.documentElement.style.setProperty('--sab','" + (sab / d) + "px');", null);
    }

    private boolean notifGranted() {
        return Build.VERSION.SDK_INT < 33
                || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == 7) {
            boolean ok = res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED;
            wv.evaluateJavascript("window.__np&&window.__np(" + ok + ")", null);
        }
    }

    private class Bridge {
        @JavascriptInterface
        public void setLight(final boolean light) {
            runOnUiThread(() -> {
                WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), wv);
                c.setAppearanceLightStatusBars(light);
                c.setAppearanceLightNavigationBars(light);
            });
        }

        @JavascriptInterface
        public boolean hasNotifPerm() { return notifGranted(); }

        @JavascriptInterface
        public void requestNotifPerm() {
            runOnUiThread(() -> {
                if (notifGranted()) wv.evaluateJavascript("window.__np&&window.__np(true)", null);
                else requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
            });
        }

        @JavascriptInterface
        public void notify(String title, String body) {
            if (!notifGranted()) return;
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm.getNotificationChannel(CH) == null)
                nm.createNotificationChannel(new NotificationChannel(CH, "تنبيهات سجل الأستاذ",
                        NotificationManager.IMPORTANCE_DEFAULT));
            PendingIntent pi = PendingIntent.getActivity(MainActivity.this, 0,
                    new Intent(MainActivity.this, MainActivity.class)
                            .setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP),
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            nm.notify(nid++, new android.app.Notification.Builder(MainActivity.this, CH)
                    .setSmallIcon(R.drawable.ic_stat)
                    .setContentTitle(title).setContentText(body)
                    .setStyle(new android.app.Notification.BigTextStyle().bigText(body))
                    .setContentIntent(pi).setAutoCancel(true).build());
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        String js = "(function(){var o=document.querySelectorAll('.ovw');"
                + "if(o.length){o[o.length-1].click();return 1}"
                + "var sh=document.getElementById('sheet');"
                + "if(sh&&sh.classList.contains('show')){sh.click();return 1}"
                + "var lg=document.getElementById('log');"
                + "if(lg&&lg.classList.contains('show')){lg.classList.remove('show');return 1}"
                + "if(typeof SO!=='undefined'&&SO){spClose();return 1}"
                + "var b=document.getElementById('back');"
                + "if(b&&b.style.display==='grid'){b.click();return 1}"
                + "return 0})()";
        wv.evaluateJavascript(js, v -> { if ("0".equals(v)) finish(); });
    }
}
